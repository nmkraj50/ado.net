﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        SqlConnection sqlcon = new SqlConnection("server=ndamssql\\sqlilearn; Database=Training_13Aug19_Pune; User Id=sqluser; password=sqluser");
        public Form1()
        {
            InitializeComponent();
        }

        private void INSERT_Click(object sender, EventArgs e)
        {
            SqlCommand sqlcmd = new SqlCommand("Insert into emp46004682 values(104,'Lina',400000)", sqlcon);
            sqlcon.Open();
            int c = sqlcmd.ExecuteNonQuery();
            MessageBox.Show("Record inserted");
            sqlcon.Close();
        }

        private void UPDATE_Click(object sender, EventArgs e)
        {
            SqlCommand sqlcmd = new SqlCommand("update emp46004682 set salary = 60000 where empid=104", sqlcon);
            sqlcon.Open();
            int c = sqlcmd.ExecuteNonQuery();
            MessageBox.Show("Record updated");
            sqlcon.Close();
        }

        private void DELETE_Click(object sender, EventArgs e)
        {
            SqlCommand sqlcmd = new SqlCommand("DELETE from emp46004682 where empid=104", sqlcon);
            sqlcon.Open();
            int c = sqlcmd.ExecuteNonQuery();
            MessageBox.Show("Record updated");
            sqlcon.Close();
        }
    }
}
