﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApp3
{
    public partial class Form1 : Form
    {
        SqlConnection sqlcon;
        string sqlconnectstring = "server=ndamssql\\sqlilearn;database=Training_13Aug19_Pune;user Id=sqluser; password=sqluser";

        public Form1()
        {
            InitializeComponent();
        }

        private void displaycount_Click(object sender, EventArgs e)
        {
            string sqlSelect = "select max(salary) from emp46004682";
            sqlcon = new SqlConnection(sqlconnectstring);
            SqlCommand cmdquery = new SqlCommand(sqlSelect);
            cmdquery.Connection = sqlcon;
            sqlcon.Open();
            int max = Convert.ToInt32(cmdquery.ExecuteScalar());
            sqlcon.Close();
            MessageBox.Show("Max salary=" + max);
        }
    }
}
