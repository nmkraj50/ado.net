﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApp4
{
    public partial class Form1 : Form
    {
        
        public Form1()
        {
            InitializeComponent();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }
        SqlConnection sqlcon = new SqlConnection("server=ndamssql\\sqlilearn; Database=Training_13Aug19_Pune; User Id=sqluser; password=sqluser");
        private void button1_Click(object sender, EventArgs e)
        {
            
            SqlCommand sqlcmd = new SqlCommand("GetEmp46004682", sqlcon);
            sqlcmd.CommandType = CommandType.StoredProcedure;
            SqlDataReader sqldr;
            sqlcon.Open();
            sqldr = sqlcmd.ExecuteReader();
            while (sqldr.Read())
            {
                listBox1.Items.Add(sqldr.GetInt32(0) + " " + sqldr.GetString(1) + " " + sqldr.GetInt32(2));
                
            }
            sqldr.Close();
            sqlcon.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            SqlCommand sqlcmd = new SqlCommand("empdpt46004682", sqlcon);
            sqlcmd.CommandType = CommandType.StoredProcedure;
            SqlDataReader sqldr;
            //sqlcmd.Parameters.AddWithValue("@deptid",txtdeptid.Text);
            SqlParameter p1 = new SqlParameter();
            p1.ParameterName = "@deptid";
            p1.Value = txtdeptid.Text;
            sqlcmd.Parameters.Add(p1);
            sqlcon.Open();
            sqldr = sqlcmd.ExecuteReader();
            lstemployee2.Items.Clear();
            while (sqldr.Read())
            {
                lstemployee2.Items.Add(sqldr.GetInt32(0) + " " + sqldr.GetString(1) + " " + sqldr.GetInt32(2));
            }
            sqldr.Close();
            sqlcon.Close();
        }
    }
}
