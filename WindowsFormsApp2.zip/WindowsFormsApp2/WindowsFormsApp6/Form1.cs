﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApp6
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        SqlConnection sqlcon = new SqlConnection("server=ndamssql\\sqlilearn; Database=Training_13Aug19_Pune; User Id=sqluser; password=sqluser");
        private void button1_Click(object sender, EventArgs e)
        {
            SqlCommand sqlcmd = new SqlCommand("countemp46004682", sqlcon);
            sqlcmd.CommandType = CommandType.StoredProcedure;
            SqlParameter p1 = new SqlParameter();
            p1.ParameterName = "@deptid";
            p1.Value = txtdeptid.Text;
            p1.Direction = ParameterDirection.Input;

            SqlParameter p2 = new SqlParameter();
            p2.ParameterName = "@empcount";
            p2.Size = 10;
            p2.Direction = ParameterDirection.Output;

            sqlcmd.Parameters.Add(p1);
            sqlcmd.Parameters.Add(p2);

            sqlcon.Open();
            sqlcmd.ExecuteScalar();
            string empcount = (string)sqlcmd.Parameters["@empcount"].Value;
            sqlcon.Close();
            MessageBox.Show(empcount);
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
