﻿namespace WindowsFormsApp5
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txtempid = new System.Windows.Forms.TextBox();
            this.textempname = new System.Windows.Forms.TextBox();
            this.txtempsal = new System.Windows.Forms.TextBox();
            this.textempdept = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(135, 93);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(97, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Enter employee ID:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(135, 137);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(115, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Enter Employee Name:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(135, 191);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(114, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Enter Employee salary:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(135, 249);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(122, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Enter Employee dept ID:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(251, 40);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(147, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "Insert using stored procedure:";
            // 
            // txtempid
            // 
            this.txtempid.Location = new System.Drawing.Point(396, 93);
            this.txtempid.Name = "txtempid";
            this.txtempid.Size = new System.Drawing.Size(118, 20);
            this.txtempid.TabIndex = 5;
            // 
            // textempname
            // 
            this.textempname.Location = new System.Drawing.Point(396, 137);
            this.textempname.Name = "textempname";
            this.textempname.Size = new System.Drawing.Size(118, 20);
            this.textempname.TabIndex = 6;
            // 
            // txtempsal
            // 
            this.txtempsal.Location = new System.Drawing.Point(396, 184);
            this.txtempsal.Name = "txtempsal";
            this.txtempsal.Size = new System.Drawing.Size(118, 20);
            this.txtempsal.TabIndex = 7;
            // 
            // textempdept
            // 
            this.textempdept.Location = new System.Drawing.Point(396, 249);
            this.textempdept.Name = "textempdept";
            this.textempdept.Size = new System.Drawing.Size(118, 20);
            this.textempdept.TabIndex = 8;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(157, 334);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 9;
            this.button1.Text = "INSERT";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(615, 467);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.textempdept);
            this.Controls.Add(this.txtempsal);
            this.Controls.Add(this.textempname);
            this.Controls.Add(this.txtempid);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtempid;
        private System.Windows.Forms.TextBox textempname;
        private System.Windows.Forms.TextBox txtempsal;
        private System.Windows.Forms.TextBox textempdept;
        private System.Windows.Forms.Button button1;
    }
}

