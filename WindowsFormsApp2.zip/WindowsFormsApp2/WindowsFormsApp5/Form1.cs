﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApp5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        SqlConnection sqlcon = new SqlConnection("server=ndamssql\\sqlilearn; Database=Training_13Aug19_Pune; User Id=sqluser; password=sqluser");
        private void button1_Click(object sender, EventArgs e)
        {
            sqlcon.Open();
            SqlCommand cmdinsert = new SqlCommand();
            cmdinsert.Connection = sqlcon;
            cmdinsert.CommandType = CommandType.StoredProcedure;
            cmdinsert.CommandText = "insertemp46004682";
            cmdinsert.Parameters.AddWithValue("@empid", txtempid.Text);
            cmdinsert.Parameters.AddWithValue("@empname", textempname.Text);
            cmdinsert.Parameters.AddWithValue("@salary", txtempsal.Text);
            cmdinsert.Parameters.AddWithValue("@deptid", textempdept.Text);
            int iRowsAffected = cmdinsert.ExecuteNonQuery();
            if(iRowsAffected>=1)
            {
                MessageBox.Show("Data Inserted");
            }
            
            sqlcon.Close();
        }
    }
}
