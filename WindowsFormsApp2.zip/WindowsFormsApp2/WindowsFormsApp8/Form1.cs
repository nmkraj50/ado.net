﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;

namespace WindowsFormsApp8
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btndisplay_Click(object sender, EventArgs e)
        {
            string connstring = ConfigurationManager.ConnectionStrings["constr"].ToString();
            SqlConnection sqlcon = new SqlConnection(connstring);
            SqlDataAdapter da = new SqlDataAdapter("select * from emp46004682",sqlcon);
            DataSet ds = new DataSet();
            try
            {
                da.Fill(ds, "Employee");
                dataGridView1.DataSource = ds.Tables["Employee"];
            }
            catch(SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
