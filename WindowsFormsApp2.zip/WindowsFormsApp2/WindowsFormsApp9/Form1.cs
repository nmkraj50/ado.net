﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;


namespace WindowsFormsApp9
{
    public partial class Form1 : Form
    {
        SqlConnection sqlcon;
        SqlDataAdapter adapter;
        SqlCommandBuilder builder;
        DataSet ds;
        public Form1()
        {
            InitializeComponent();
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                DataRow row = ds.Tables["Employee"].NewRow();
                row["empid"] = empid.Text;
                row["ename"] = ename.Text;
                row["salary"] = sal.Text;
                row["deptid"] = deptid.Text;
                ds.Tables["Employee"].Rows.Add(row);
                MessageBox.Show("current Row status:" + row.RowState.ToString());
                int result = adapter.Update(ds, "Employee");
                if(result>=1)
                {
                    MessageBox.Show("employee added");
                }
                else
                {
                    MessageBox.Show("not added");
                }
            }
            catch(SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        
        private void Form1_Load(object sender, EventArgs e)
        {

            string connstring = ConfigurationManager.ConnectionStrings["constr"].ToString();
            SqlConnection sqlcon = new SqlConnection(connstring);
            adapter = new SqlDataAdapter("select * from emp46004682", sqlcon);
            builder = new SqlCommandBuilder(adapter);
            ds = new DataSet();
            adapter.Fill(ds, "Employee");
        }
    }
}
