﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;

namespace WindowsFormsApp10
{
    public partial class Form1 : Form
    {
        SqlConnection sqlcon;
        SqlDataAdapter adapter;
        SqlCommandBuilder builder;
        DataSet ds;
        DataRow drow;
        public Form1()
        {
            InitializeComponent();
        }
        public void ShowDetails()
        {
            adapter.Fill(ds, "Employee");
            drow = ds.Tables[0].Rows.Find(empid.Text);
            ename.Text = drow[1].ToString();
            sal.Text = drow[2].ToString();
            deptid.Text = drow[3].ToString();

        }
        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void btnupdate_Click(object sender, EventArgs e)
        {
            drow[1] = ename.Text;
            drow[2] = sal.Text;
            drow[3] = deptid.Text;
            MessageBox.Show("Current Row Status:" + drow.RowState.ToString());
            try
            {
                int result = adapter.Update(ds, "Employee");
                if (result > 0)
                {
                    MessageBox.Show("updated");
                }
                else
                    MessageBox.Show("not updated");
            }
            catch(SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnshow_Click(object sender, EventArgs e)
        {

        }
    }
}
